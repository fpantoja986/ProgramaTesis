<?php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'techcommunity934@gmail.com');
define('SMTP_PASSWORD', 'pdnz wnvd jcgq xfac');
define('SMTP_SECURE', 'tls');
define('SMTP_PORT', 587);

define('FROM_EMAIL', 'techcommunity934@gmail.com');
define('FROM_NAME', 'Tech Community');

define('BASE_URL', 'https://tesis2025.infinityfreeapp.com');

define('EMAIL_CHARSET', 'UTF-8');
define('EMAIL_DEBUG', true);
define('EMAIL_FORCE_PLAIN', false);
?>
