<?php
/**
 * Configuración de correo electrónico
 * Configura las constantes necesarias para el envío de correos
 */

// Configuración SMTP
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'fpantoja986@gmail.com');
define('SMTP_PASSWORD', 'jxkg ncjw cnxo dsmq');
define('SMTP_SECURE', 'tls');
define('SMTP_PORT', 587);

// Configuración del remitente
define('FROM_EMAIL', 'fpantoja986@gmail.com');
define('FROM_NAME', 'Mujeres en Tech');

// URL base de la aplicación
define('BASE_URL', 'http://localhost:8080/ProgramaTesis'); // Cambia por tu URL

// Configuración adicional
define('MAIL_CHARSET', 'UTF-8');
define('MAIL_ENCODING', '8bit');
?>
